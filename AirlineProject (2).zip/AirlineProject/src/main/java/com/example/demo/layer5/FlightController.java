package com.example.demo.layer5;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Flight;
import com.example.demo.layer4.FlightService;
import com.example.demo.layer4.exceptions.UserAlreadyExistsException;
import com.example.demo.layer4.exceptions.UserNotFoundException;

@RestController
public class FlightController {

	@Autowired
	FlightService flightServ;
	
	@GetMapping(path="/getFlight/{myFlightId}")
	@ResponseBody
	public ResponseEntity<Flight> getFlight(@PathVariable("myFlightId") int flightId){
		System.out.println("Flight Controller....Understanding client and talking to service layer...");
		Flight flightObj =null;
		
		flightObj = flightServ.findFlightService();
		
		if(flightObj==null)
		{ return ResponseEntity.notFound().build();
		
		}
		else {
			return ResponseEntity.ok(flightObj);
		} 
	}
	
	@GetMapping(path="/getFlights")
	@ResponseBody
	public Set<Flight> getAllFlightService() {
		System.out.println("Flight Controller....Understanding client and talking to service layer...");
		Set<Flight> flightList = flightServ.findAllFlightService();
		return flightList;
		
	}

	/*@PostMapping(path="/addflight")
	public String addSignup(@RequestBody Flight flight) {
		System.out.println("Flight Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		
		 Flight addflight =new Flight();
			//Date date = new SimpleDateFormat("DD-MMM-YY").parse("30-Apr-1998");
			addflight.getFlightid();
			
		try {
			stmsg = signupServ.addSignupService(addurs);
		} 
		catch (UserAlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}*/
	
	@PutMapping(path="/modifyFlight")
	public  String modifyFlightService(@RequestBody Flight flight)throws UserNotFoundException {
		System.out.println("flight Controller....Understanding client and talking to service layer...");
		 String stmsg = null;

		try {
			stmsg= flightServ.modifyFlightService(flight);
		} 
		catch (UserNotFoundException e) {
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
	
	/*
	@DeleteMapping(path="/deleteUser") //notworking
	public String removeSignup(@RequestBody Signup signup)throws UserNotFoundException {
		System.out.println("signup Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			//int userid = signup.getUserid();
			stmsg = signupServ.removeSignupService(signup.getUserid());
		} 
		catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
	}
	*/
	
}