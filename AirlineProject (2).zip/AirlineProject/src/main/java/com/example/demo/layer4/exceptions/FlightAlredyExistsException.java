package com.example.demo.layer4.exceptions;

@SuppressWarnings("serial")
public class FlightAlredyExistsException extends Throwable {

	public FlightAlredyExistsException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
