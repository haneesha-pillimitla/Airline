export class Admin{
    adminId : number|undefined;
    adminName : string|undefined;
    password : string|undefined;
    

}