export class seats
{
    sno:number|undefined;
    seatno:string|undefined;
    passengerfullname:string|undefined;
    agegroup:number|undefined;
    ticketno:number|undefined;
    seatSet:seats[]|undefined;
}