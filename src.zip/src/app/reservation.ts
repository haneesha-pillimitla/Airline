import { Signup } from "./Signup";

export class Reservation {
    ticketno :number|undefined;
noofpassengers  :number|undefined;
class :string|undefined;
triptype :string|undefined;
dateofdeparture :string|undefined;
dateofreturn :string|undefined;
price :number|undefined;
totalprice :number|undefined;
paymentstatus :string|undefined;
ticketissue :Date|undefined;
ticketstatus :string|undefined;
flightid :number|undefined;
userid :string|undefined;
signupset:Signup[] |undefined;
    
}