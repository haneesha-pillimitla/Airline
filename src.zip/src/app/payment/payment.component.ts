import { Component, OnInit } from '@angular/core';
import { FlightService } from '../flight.service';
import { Reservation } from '../reservation';
import { Signup } from '../Signup';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
 triptype:any|undefined;
 date:any|undefined;
 noofpass:any|undefined;
 flightid:any|undefined;
 userid:any|undefined;
 price:any|undefined;
 class:any|undefined;

  constructor(private fs:FlightService) { }
reservation1:Reservation= new Reservation();
signup1:Signup=new Signup();
  ngOnInit(): void {
  }
addingreservation()
{
  this.triptype=sessionStorage.getItem("triptype");
  this.reservation1.triptype=JSON.parse(this.triptype);
  this.date=sessionStorage.getItem("date");
  this.reservation1.dateofdeparture=JSON.parse(this.date);
  this.noofpass=sessionStorage.getItem("noofpass");
  this.reservation1.noofpassengers=JSON.parse(this.noofpass);
  this.flightid=sessionStorage.getItem("id");
  this.reservation1.flightid=JSON.parse(this.flightid);
  this.userid=sessionStorage.getItem("uid");
  this.reservation1.signupset.userid=JSON.parse(this.userid);
  this.price=sessionStorage.getItem("price");
  this.reservation1.price=JSON.parse(this.price);
  this.reservation1.paymentstatus="Done";
  this.reservation1.ticketstatus="Active";
  if(this.noofpass>1)
  {
    this.reservation1.totalprice=(this.noofpass*this.price);
  }
  else
  {
    this.reservation1.totalprice=this.price;
  }
  if(this.price=3000)
  {
    this.reservation1.class="economy";
  }
  else{
    this.reservation1.class="bussines";
  }
   this.fs.addreservationService(this.reservation1).subscribe(data=>{
    console.log(data);
   })


}
}
