import { Component, OnInit } from '@angular/core';
import { FlightService } from '../flight.service';
import { Reservation } from '../reservation';
import { Signup } from '../Signup';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
 triptype:any|undefined;
 date:any|undefined;
 noofpass:any|undefined;
 flightid:any|undefined;
 uid:any|undefined;
 price:any|undefined;
 class:any|undefined;

  constructor(private fs:FlightService) { }
reservation1:Reservation= new Reservation();
//reservation2:Reservation= new Reservation();
str="";
//signup1:Signup=new Signup();
  ngOnInit(): void {
  }
addingreservation()
{
  this.triptype=sessionStorage.getItem("triptype");
  this.reservation1.triptype=JSON.parse(this.triptype);
  this.date=sessionStorage.getItem("date");
  this.reservation1.dateofdeparture=JSON.parse(this.date);
  this.noofpass=sessionStorage.getItem("noofpass");
  this.reservation1.noofpassengers=JSON.parse(this.noofpass);
  this.flightid=sessionStorage.getItem("id");
  this.reservation1.flightid=JSON.parse(this.flightid);
  this.uid=sessionStorage.getItem("uid");
  this.reservation1.userid=JSON.parse(this.uid);
  this.price=sessionStorage.getItem("price");
  this.reservation1.price=JSON.parse(this.price);
  this.reservation1.paymentstatus="Done";
  this.reservation1.ticketstatus="Active";
  if(this.noofpass>1)
  {
    this.reservation1.totalprice=(this.noofpass*this.price);
  }
  else
  {
    this.reservation1.totalprice=this.price;
  }
  if(this.price=3000)
  {
    this.reservation1.class="economy";
  }
  else{
    this.reservation1.class="bussines";
  }
   this.fs.addreservationService(this.reservation1).subscribe(data=>{
    console.log(data);
    //this.reservation2=data;
    this.str=data;
    sessionStorage.setItem("resv",JSON.stringify(this.reservation1));
    alert(this.str);
    
   })


}
}
//{"triptype":"OneWay","dateofdeparture":"2021-05-31","noofpassengers":1,"flightid":"101","userid":"1","price":3000,"paymentstatus":"Done","ticketstatus":"Active","totalprice":"3000","class":"economy"}