export  class Cancelticket  {
	cancelid:number|undefined;
 canceldate:string|undefined;
 refundamount:number|undefined;
refundstatus:string|undefined;
}