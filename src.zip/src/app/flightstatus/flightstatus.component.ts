import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flightstatus',
  templateUrl: './flightstatus.component.html',
  styleUrls: ['./flightstatus.component.css']
})
export class FlightstatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
