import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ticketdetails',
  templateUrl: './ticketdetails.component.html',
  styleUrls: ['./ticketdetails.component.css']
})
export class TicketdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
