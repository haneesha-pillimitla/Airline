import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightService } from '../flight.service';
import { Signup } from '../Signup';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

uid=0;
userid:any|undefined;
  isLoggedIn=false;
  signup:Signup=new Signup();
  constructor(private router:Router, private fs:FlightService) { }

  ngOnInit(): void {
    
  }

ticket(){
this.router.navigate(["/cancel"]);
}


findUser(){
   this.router.navigate(["/userdetails"]);
}

}
